const Builder = require('../../../utils/browserBuilder'),
    LoginPage = require('../../../pages/backoffice/admin/loginPage');

(async function testLogin() {
    let driver = await Builder.createDriver();

    try {
        const loginPage = new LoginPage(driver);

        await loginPage.navigate();
        await loginPage.setMail('attus.domingos@doutbox.com.br');
        await loginPage.setPassword('asd');
        await loginPage.clickLoginButton();

        console.assert((await driver.getTitle()) === 'Homolog Virada de Vida | Dashboard', 'Falha no login!');
    } catch (error) {
        console.error('Erro:', error);
    } finally {
        await driver.quit();
    }
})();
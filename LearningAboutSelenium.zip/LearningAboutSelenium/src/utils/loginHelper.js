const LoginPage = require('../pages/backoffice/admin/loginPage');

async function makeLogin (mail, password) {
    await this.navigate();
    await this.setMail(mail);
    await this.setPassword(password);
    await this.clickLoginButton()
}

module.exports = { makeLogin }
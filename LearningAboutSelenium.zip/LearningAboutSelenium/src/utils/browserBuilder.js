const { Builder } = require('selenium-webdriver');

module.exports = {
    /**
     * @param browser
     * @returns {!ThenableWebDriver}
     */
    createDriver: (browser = 'chrome') => {
        return new Builder().forBrowser(browser).build();
    }
}
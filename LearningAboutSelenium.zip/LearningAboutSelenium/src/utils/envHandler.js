const {config} = require('dotenv')

exports.build = (() => {
        config();
    }
);
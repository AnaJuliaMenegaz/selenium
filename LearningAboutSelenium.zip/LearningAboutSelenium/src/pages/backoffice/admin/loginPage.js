const {By} = require('selenium-webdriver');

class LoginPage {
    constructor(driver) {
        this.driver = driver;
    }

    /**
     * @returns {Promise<void>}
     */
    async navigate() {
        await this.driver.get('https://homologbackoffice.viradadevida.me/login')
    }

    /**
     * @param mail
     * @returns {Promise<void>}
     */
    async setMail(mail) {
        await this.driver.findElement(By.id('default-01')).sendKeys(mail);
    }

    /**
     * @param password
     * @returns {Promise<void>}
     */
    async setPassword(password) {
        await this.driver.findElement(By.id('password')).sendKeys(password);
    }

    /**
     * @returns {Promise<void>}
     */
    async clickLoginButton() {
        await this.driver.findElement(By.css('button[type="submit"]')).click();
    }
}

module.exports = LoginPage
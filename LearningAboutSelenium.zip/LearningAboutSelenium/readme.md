# Selenium

1. O que é.
    1. Como descrito pela própria documentação do Selenium, ele é e serve para muitas coisas, mas sua essência, é um
       conjuto de ferramentes para automação de navegadores, e é essa essência que iremos explorar e utilizar durante
       esse estudo.
2. Para que serve.
    1. Testes automatizados.
        1. Esse é o tópico que estaremos realizando o estudo e aplicação.
    2. Automação de tarefas repetitivas.
        1. Ué, mas como assim automação, isso já não é a mesma coisa que o tópicos anterior? Não necessariamente,
           podemos utilizar como por exemplo o que temos que fazer diariamente dentro da empresa, como por exemplo bater
           o ponto, até fazer o nosso apontamento de horas, a maior parte das atividades que realizamos ficar "apontada"
           no gitlab, e algumas vezes utilizamos ele complemento para o apontamento de horas, porém, com uma boa analise
           e algum tempo de desenvolvimento, poderiamos utilizar o selenium para pegar os dados do dashboard do gitlab e
           fazer o preenchimento no octopoda.
        2. Podemos usar a automação de tarefas repetitivas para explicar melhor qual o intuito dos testes automatizados
           com o selenium, por exemplo, foi desenvolvido um cadastro de usuário e foi realizado o teste manual para
           testar esse fluxo, o cadastro, atualização e exclusão, porém, em algumas atividades mais para frente foi
           desenvolvido um fluxo de permissão de acesso, e agora cada usuário no seu cadastro deve ser declaro qual o
           nível de acesso do usuário, sem um teste automatizado teria que ser feito o teste manual de todos 3 fluxos
           novamente, cadastro, edição e exclusão, com um teste automatizado, poderiamos apenas adicionar o novo campo
           nos testes e deixar a automação fazer o resto.
       3. Extração de dados para sites que dificultam coleta de dados via js.
       4. Teste de desempenho.
       5. Realização de auditorias e acessibilidade.
3. Como podemos utilizar.
    1. O selenium nós podemos utilizar de várias formas e linguagens diferentes, como Python, C#, Js, Java e etc.
    2. Nós iremos utilizar o Js para fazer os teste automatizados, por sua praticidade e de não precisar de quase nada
       para rodar o selenium testes automatizados com selenium.

---

# Primeiros passos

1. Iniciar um projeto
   1. Requisitos:
      1. NodeJs.
         1. Seguir processo de Download do NodeJs no site https://nodejs.org/.
      2. Instalação do web driver
         1. Manualmente (Linux):
            1. Chrome:
               1. Pegar a versão atual:
                  1. Executar no terminal:
                     1. ```shell
                        google-chrome --version
                        ```
                  2. Resultado: 130.0.6723.116
                     5. https://storage.googleapis.com/chrome-for-testing-public/130.0.6723.116/linux64/chromedriver-linux64.zip
                  3. Terminal:
                     1. `wget https://storage.googleapis.com/chrome-for-testing-public/130.0.6723.116/linux64/chromedriver-linux64.zip`
                  4. Depois de baixar o zip:
                  5. ```shell
                     unzip chromedriver-linux64.zip
                     sudo mv chromedriver-linux64/chromedriver /usr/local/bin/
                     sudo chmod +x /usr/local/bin/chromedriver
                     chromedriver --version
                     ```
         2. Utilizando o Npm:
            1. `npm install webdriver-manager`
            2. `npx webdriver-manager update`
2. Estrutura base
   1. ```js
      const { Builder } = require('selenium-webdriver');

      (async function example() {
        let driver = await new Builder().forBrowser('chrome').build();
        // Do something
      })();
      ```
   2. O `Builder` serve para criar uma instância do WebDriver, que iremos utilizar para emular o navegador e realizarmos
      os testes.
   3. A partir do `Builder` iremos inicialmente dar um `build` nele declarando o chrome como navegador utilizando o 
      o método `forBrowser`.
3. Acesso as páginas
   1. Possuindo nosso `driver` definido, podemos começar a navegar pelas aplicações e páginas.
   2. Exemplo de acesso: `await driver.get('https://google.com');`
   3. Ficando da seguinte forma no final.
      1. ```js
         const { Builder } = require('selenium-webdriver');

         (async function example() {
           let driver = await new Builder().forBrowser('chrome').build();

            await driver.get('https://google.com');
         })();
         ```
   4. O exemplo acima irá abrir o navegador e irá acessar a página inicial do Google.
4. Seleção de elementos
   1. Agora para interagir com o elementos da página, existem várias maneiras, pelo elemento, por css, pelo xpath.
      1. Para mais info e exemplos: https://www.selenium.dev/documentation/webdriver/elements/finders/
   2. Nesse exemplo iremos utilizar o por elemento.
      1. Ficando assim: `const searchBox = await driver.findElement(By.name('q'));`
      2. No exemplo acima o estamos utilizando o componente `By` do Selenium, que é um componente de busca de elementos.
      3. O exemplo acima irá buscar na página um elemento que possua o atributo nome `q`. Que no caso é o campo de busca
         da página inicial do google.
      4. Ficando no final assim: 
         1. ```js
            const { Builder } = require('selenium-webdriver');
            
            (async function example() {
                let driver = await new Builder().forBrowser('chrome').build();
                
                await driver.get('https://google.com');
                
                const searchBox = await driver.findElement(By.name('q'));
            })();
            ```
      5. Como isso ainda não irá causar efeito nenhum, irá apenas encontrar o elemento, vamos fazer uma busca.
         1. `await searchBox.sendKeys('Selenium WebDriver', Key.RETURN);`
         2. Esse código irá pegar o elemento que selecionamos no exemplo anterior e irá preencher com o `Selenium WebDriver`,
            e depois irá realizar o submit do formulário com o `Key.RETURN`.
         3. Esse fluxo fará com o teste acesse a página inicial do google, pegue o input de pesquisa e realize a
            pesquisa sobre `Selenium WebDriver`.
         4. Esse é um exemplo simples, mas só com isso já temos como realizar logins, cadastros e afins.
   3. Acesse o arquivo [index.js](./index.js) para um exemplo completo e com mais algumas funcionalidades.
5. Estrutura ideal
   1. ...